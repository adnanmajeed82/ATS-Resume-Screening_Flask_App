from flask import Flask, render_template, request, redirect, url_for, flash
import fitz  # PyMuPDF

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # for flash messages

# Skills list
skills = [
    'Python', 'Java', 'Machine Learning', 'Data Analysis', 'SQL', 'AWS', 
    'JavaScript', 'Django', 'Flask', 'Project Management', 'Leadership'
]

def extract_text_from_pdf(file_path):
    """Extracts text from a PDF file."""
    text = ""
    with fitz.open(file_path) as pdf:
        for page_num in range(pdf.page_count):
            page = pdf[page_num]
            text += page.get_text()
    return text

def calculate_ats_score(resume_text, skills):
    """Calculates ATS score based on matching skills."""
    matched_skills = [skill for skill in skills if skill.lower() in resume_text.lower()]
    score = len(matched_skills) / len(skills) * 100
    return round(score, 2), matched_skills

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)

        file = request.files['file']
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)

        if file and file.filename.endswith('.pdf'):
            file_path = 'uploaded_resume.pdf'
            file.save(file_path)
            
            # Extract text and calculate ATS score
            resume_text = extract_text_from_pdf(file_path)
            score, matched_skills = calculate_ats_score(resume_text, skills)
            unmatched_skills = [skill for skill in skills if skill not in matched_skills]

            return render_template('index.html', score=score, matched_skills=matched_skills, unmatched_skills=unmatched_skills)

        else:
            flash('Invalid file format. Please upload a PDF file.')
            return redirect(request.url)

    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
